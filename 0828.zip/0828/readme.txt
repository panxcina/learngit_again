change vanilla themes css fie
src:\ofbizMonitor\themes\vanilla\webapp\vanilla\css