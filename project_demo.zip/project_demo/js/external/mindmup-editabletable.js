/*global $, window*/
$.fn.editableTableWidget = function (options) {
	'use strict';
	return $(this).each(function () {
		var buildDefaultOptions = function () {
				var opts = $.extend({}, $.fn.editableTableWidget.defaultOptions);
				opts.editor = opts.editor.clone();
				return opts;
			},
			activeOptions = $.extend(buildDefaultOptions(), options),
			ARROW_LEFT = 37, ARROW_UP = 38, ARROW_RIGHT = 39, ARROW_DOWN = 40, ENTER = 13, ESC = 27, TAB = 9,
			element = $(this),
			editor = activeOptions.editor.css('position', 'absolute').hide().appendTo(element.parent()),
			active,
			active0,active1,active2,active3,active4,active5,active6,active7,active8,active9,active10,active11,active12,active13,
			active14,active15,active16,active17,active18,
			showEditor = function (select) {
			// var active_Array = new Array(36),
				active = element.find('td:focus');
				active0 = element.find('td.my_class0:focus');
				active1 = element.find('td.my_class1:focus');
				active2 = element.find('td.my_class2:focus');
				active3 = element.find('td.my_class3:focus');
				active4 = element.find('td.my_class4:focus');
				active5 = element.find('td.my_class5:focus');
				active6 = element.find('td.my_class6:focus');
				active7 = element.find('td.my_class7:focus');
				active8 = element.find('td.my_class8:focus');
				active9 = element.find('td.my_class9:focus');
				active10 = element.find('td.my_class10:focus');
				active11 = element.find('td.my_class11:focus');
				active12 = element.find('td.my_class12:focus');
				active13 = element.find('td.my_class13:focus');
				active14 = element.find('td.my_class14:focus');
				active15 = element.find('td.my_class15:focus');
				active16 = element.find('td.my_class16:focus');
				active17 = element.find('td.my_class17:focus');
				active18 = element.find('td.my_class18:focus');
				
				if (active.length) {
					editor.val(active.text())
						.removeClass('error')
						.show()
						.offset(active.offset())
						.css(active.css(activeOptions.cloneProperties))
						.width(active.width())
						.height(active.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active0.length) {
					editor.val(active0.text())
						.removeClass('error')
						.show()
						.offset(active0.offset())
						.css(active0.css(activeOptions.cloneProperties))
						.width(active0.width())
						.height(active0.height())
						.attr({"pattern":"^[A-Z0-9-]*$", "title":"输入字母必须是大写", "data-toggle":"tooltip", "data-placement":"bottom", "data-original-title":"输入字母必须是大写"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active1.length) {
					editor.val(active1.text())
						.removeClass('error')
						.show()
						.offset(active1.offset())
						.css(active1.css(activeOptions.cloneProperties))
						.width(active1.width())
						.height(active1.height())
						.attr({"pattern":"^[A-Z0-9-]{7}$", "title":"必须满足7位", "data-toggle":"tooltip", "data-placement":"bottom", "data-original-title":"必须满足7位"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active2.length) {
					editor.val(active2.text())
						.removeClass('error')
						.show()
						.offset(active2.offset())
						.css(active2.css(activeOptions.cloneProperties))
						.width(active2.width())
						.height(active2.height())
						.attr({"title":"输入无限制", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active3.length) {
					editor.val(active3.text())
						.removeClass('error')
						.show()
						.offset(active3.offset())
						.css(active3.css(activeOptions.cloneProperties))
						.width(active3.width())
						.height(active3.height())
						.attr({pattern:"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active4.length) {
					editor.val(active4.text())
						.removeClass('error')
						.show()
						.offset(active4.offset())
						.css(active4.css(activeOptions.cloneProperties))
						.width(active4.width())
						.height(active4.height())
						.attr({"pattern":"^[(\u4E00-\u9FA5)*{2,15}A-Za-z0-9 ]{2,15}$", "title": "必须有中文字符且小于15个字符", "data-original-title":"必须有中文字符且小于15个字符", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active5.length) {
					editor.val(active5.text())
						.removeClass('error')
						.show()
						.offset(active5.offset())
						.css(active5.css(activeOptions.cloneProperties))
						.width(active5.width())
						.height(active5.height())
						.attr({"pattern":"^[A-Za-z0-9 ]{1,30}$", "title":"英文数字小于30个字符", "data-original-title":"英文数字小于30个字符", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active6.length) {
					editor2.val(active6.text())
						.removeClass('error')
						.show()
						.offset(active6.offset())
						.css(active6.css(activeOptions.cloneProperties))
						.width(active6.width())
						.height(active6.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor2.select();

					}
				}
				if (active7.length) {
					editor.val(active7.text())
						.removeClass('error')
						.show()
						.offset(active7.offset())
						.css(active7.css(activeOptions.cloneProperties))
						.width(active7.width())
						.height(active7.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor2.select();

					}
				}
				if (active8.length) {
					editor.val(active8.text())
						.removeClass('error')
						.show()
						.offset(active8.offset())
						.css(active8.css(activeOptions.cloneProperties))
						.width(active8.width())
						.height(active8.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor2.select();

					}
				}
				if (active9.length) {
					editor.val(active9.text())
						.removeClass('error')
						.show()
						.offset(active9.offset())
						.css(active9.css(activeOptions.cloneProperties))
						.width(active9.width())
						.height(active9.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active10.length) {
					editor.val(active10.text())
						.removeClass('error')
						.show()
						.offset(active10.offset())
						.css(active10.css(activeOptions.cloneProperties))
						.width(active10.width())
						.height(active10.height())
						.attr({"pattern":"^(?!.*, ).*$", "title":" ", "data-toggle":"", "data-placement":"", "data-original-title":" "})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active11.length) {
					editor.val(active11.text())
						.removeClass('error')
						.show()
						.offset(active11.offset())
						.css(active11.css(activeOptions.cloneProperties))
						.width(active11.width())
						.height(active11.height())
						.attr({"pattern":"^[0-9]*[1-9][0-9]*$", "title":"只能是整数", "data-original-title":"只能是整数", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active12.length) {
					editor.val(active12.text())
						.removeClass('error')
						.show()
						.offset(active12.offset())
						.css(active12.css(activeOptions.cloneProperties))
						.width(active12.width())
						.height(active12.height())
						.attr({"pattern":"^\\d+$", "title":"大于等于0的正整数", "data-original-title":"大于等于0的正整数", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active13.length) {
					editor.val(active13.text())
						.removeClass('error')
						.show()
						.offset(active13.offset())
						.css(active13.css(activeOptions.cloneProperties))
						.width(active13.width())
						.height(active13.height())
						.attr({"pattern":"^([0-9]*[1-9][0-9]*(\.[0-9]+)?|[0]+\.[0-9]*[1-9][0-9]*)$", "title":"大于等于0的数", "data-original-title":"大于等于0的数", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active14.length) {
					editor.val(active14.text())
						.removeClass('error')
						.show()
						.offset(active14.offset())
						.css(active14.css(activeOptions.cloneProperties))
						.width(active14.width())
						.height(active14.height())
						.attr({"pattern":"^[0-9]*(\.{1})?([0-91-9][0-9])?$", "title":"大于等于0,小数点后两位", "data-original-title":"大于等于0,小数点后两位", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active15.length) {
					editor.val(active15.text())
						.removeClass('error')
						.show()
						.offset(active15.offset())
						.css(active15.css(activeOptions.cloneProperties))
						.width(active15.width())
						.height(active15.height())
						.attr({"pattern":"^[0-9]*(\.{1})?([0-91-9][0-9])?$", "title":"大于等于0,小数点后两位", "data-original-title":"大于等于0,小数点后两位", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active16.length) {
					editor.val(active16.text())
						.removeClass('error')
						.show()
						.offset(active16.offset())
						.css(active16.css(activeOptions.cloneProperties))
						.width(active16.width())
						.height(active16.height())
						.attr({"pattern":"^[0-9]*(\.{1})?([0-91-9][0-9])?$", "title":"大于等于0,小数点后两位", "data-original-title":"大于等于0,小数点后两位", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active17.length) {
					editor.val(active17.text())
						.removeClass('error')
						.show()
						.offset(active17.offset())
						.css(active17.css(activeOptions.cloneProperties))
						.width(active17.width())
						.height(active17.height())
						.attr({"pattern":"^[0-9]*(\.{1})?([0-91-9][0-9])?$", "title":"大于等于0,小数点后两位", "data-original-title":"大于等于0,小数点后两位", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}
				if (active18.length) {
					editor.val(active18.text())
						.removeClass('error')
						.show()
						.offset(active18.offset())
						.css(active18.css(activeOptions.cloneProperties))
						.width(active18.width())
						.height(active18.height())
						.attr({"pattern":"^[0-9]*(\.{1})?([0-91-9][0-9])?$", "title":"大于等于0,小数点后两位", "data-original-title":"大于等于0,小数点后两位", "data-toggle":"tooltip", "data-placement":"bottom"})
						.focus();
					if (select) {
						editor.select();

					}
				}

			},
			setActiveText = function () {
				var text = editor.val(),
					evt = $.Event('change'),
					originalContent;
				if (active.text() === text || editor.hasClass('error')) {
					return true;
				}
				if (active0.text() === text || editor.hasClass('error')) {
					return true;
				}
				if (active1.text() === text || editor.hasClass('error')) {
					return true;
				}
				if (active2.text() === text || editor.hasClass('error')) {
					return true;
				}
				originalContent = active.html();
				active.text(text).trigger(evt, text);
				if (evt.result === false) {
					active.html(originalContent);
				}
			},
			movement = function (element, keycode) {
				if (keycode === ARROW_RIGHT) {
					return element.next('td');
				} else if (keycode === ARROW_LEFT) {
					return element.prev('td');
				} else if (keycode === ARROW_UP) {
					return element.parent().prev().children().eq(element.index());
				} else if (keycode === ARROW_DOWN) {
					return element.parent().next().children().eq(element.index());
				}
				return [];
			};
		editor.blur(function () {
			setActiveText();
			editor.hide();
		}).keydown(function (e) {
			if (e.which === ENTER) {
				setActiveText();
				editor.hide();
				active.focus();
				e.preventDefault();
				e.stopPropagation();
			} else if (e.which === ESC) {
				editor.val(active.text());
				e.preventDefault();
				e.stopPropagation();
				editor.hide();
				active.focus();
			} else if (e.which === TAB) {
				active.focus();
			} else if (this.selectionEnd - this.selectionStart === this.value.length) {
				var possibleMove = movement(active, e.which);
				if (possibleMove.length > 0) {
					possibleMove.focus();
					e.preventDefault();
					e.stopPropagation();
				}
			}
		})
		.on('input paste', function () {
			var evt = $.Event('validate');
			active.trigger(evt, editor.val());
			if (evt.result === false) {
				editor.addClass('error');
			} else {
				editor.removeClass('error');
			}
		});
		element.on('click keypress dblclick', showEditor)
		.css('cursor', 'pointer')
		.keydown(function (e) {
			var prevent = true,
				possibleMove = movement($(e.target), e.which);
			if (possibleMove.length > 0) {
				possibleMove.focus();
			} else if (e.which === ENTER) {
				showEditor(false);
			} else if (e.which === 17 || e.which === 91 || e.which === 93) {
				showEditor(true);
				prevent = false;
			} else {
				prevent = false;
			}
			if (prevent) {
				e.stopPropagation();
				e.preventDefault();
			}
		});

		element.find('td').prop('tabindex', 1);
		// element.find('td').prop('class', my_class);

		$(window).on('resize', function () {
			if (editor.is(':visible')) {
				editor.offset(active.offset())
				.width(active.width())
				.height(active.height());
			}
		});
	});

};
$.fn.editableTableWidget.defaultOptions = {
	// cloneProperties: ['padding', 'padding-top', 'padding-bottom', 'padding-left', 'padding-right',
	// 				  'text-align', 'font', 'font-size', 'font-family', 'font-weight',
	// 				  'border', 'border-top', 'border-bottom', 'border-left', 'border-right'],
	cloneProperties: ['padding', 'padding-top', 'padding-bottom', 'padding-left', 'padding-right',
					'text-align', 'font', 'font-size', 'font-family', 'font-weight', 'border',
					 'border-style'],
	// cloneProperties: ['padding', 'border-top'],
	// attr: ['title': 'not allow , ' , 'pattern': '^(?!.*, ).*$'],
	// editor: $('<input id="text_test" pattern="^(?!.*, ).*$" autofocus title="not allow , " style="">')
	editor: $('<input id="text_test">')
};

